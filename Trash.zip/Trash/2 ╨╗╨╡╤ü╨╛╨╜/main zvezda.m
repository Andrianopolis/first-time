//
//  main.m
//  hellow
//
//  Created by user03 on 18.01.17.
//  Copyright © 2017 E. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"


//int main (int argc, char * argv[])
int main()
{
       
        
        @autoreleasepool
            {
               // int main(int argc, char * argv[])
                
                {
                    // let lower : UInt32 = 1
                    
                    //let upper : UInt32 = 9
                    
                    int randomNumber = arc4random() %15; //_uniform((upper - lower) + 1) + lower
                    for (int i=0 ; i == randomNumber ; i++ )
                        
                    {
                        
                        NSLog (@ "  *  ");
                        
                        NSLog (@ " *** ");
                        
                        NSLog (@ "*****");
                        
                        NSLog (@ " *** ");
                        
                        NSLog (@ "  *  ");
                        
                    } ;
                    
             //       return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
                }
            }
            }
