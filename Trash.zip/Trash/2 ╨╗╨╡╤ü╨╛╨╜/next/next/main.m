//
//  main.m
//  next
//
//  Created by user03 on 23.01.17.
//  Copyright © 2017 E. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import <Foundation/NSArray.h>
#import <Foundation/NSString.h>
#import <Foundation/NSAutoreleasePool.h>


int main(int argc, char * argv[])
{
@autoreleasepool
    {
        int nomerNedeli;
        int randoma = arc4random() % 6;
        int randoma2 = arc4random() % 6;
        int newNumber = 2;
        NSArray *weakDay = [NSArray arrayWithObjects : @ "Понедельник" , @ "Вторник" ,
                            @ "Среда" ,@ "Четверг" ,@ "Пятница" ,@ "Суббота" ,@ "Воскресенье" ,nil ] ;
        
        NSLog (@ "Наш случайный день недели под номером - %i" , randoma + 1 ) ;
        NSLog (@ "  --->     %@ ", [weakDay objectAtIndex : randoma ] );
         // логика смещения
        
        randoma2 = newNumber - 1 ;
        
        NSLog (@ "Наше случайное смещение это чило - %i" , randoma2 + 1 ) ;
        NSLog (@ "Наш смещенный день недели под номером - %i" , newNumber + 1 ) ;
        NSLog (@ "  --->     %@ ", [weakDay objectAtIndex : newNumber ] );

        
        
        
                return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }

}
