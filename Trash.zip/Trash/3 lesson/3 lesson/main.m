//
//  main.m
//  3 lesson
//
//  Created by user03 on 25.01.17.
//  Copyright © 2017 E. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int sum (int , int);
int raz (int , int);
int umn (int , int);
int del (int , int);

// 



int main(int argc, char * argv[])
{
    // nachalo break;
    NSLog (@ "-------------------->");
    int peremennaya;
    peremennaya = arc4random() % 7;
    int a = peremennaya;
    for ( int i = 1 ;  ; ++i )
    {
        NSLog (@ " %i ",peremennaya);
        peremennaya = peremennaya + i;
        if ( peremennaya > 25 )
        {
            NSLog (@ " достигли 25");
            break;
        }
    }
    // nachalo funkciy
    
    
    
    NSLog (@ "-------------------->");
    NSLog (@ "-------------------->");
    
//    int a = arc4random() % 3999;
    int b = peremennaya;
NSLog (@ "pervoe chislo  =  %i" , a);
    NSLog (@ "vtoroe chislo =  %i" , b);
    sum (a,b);
    raz (a,b);
    umn (a,b);
    del (a,b);
    return 0;
    
    
    @autoreleasepool
    {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

//
int sum ( a , b )
{
    NSLog (@ "summa %i" , a+b);
    return 0;
}
//
int raz ( a , b )
{
    NSLog (@ "raznica %i" , a-b);
    return 0;
}
//
int umn ( a , b )
{
    NSLog (@ "umnogenie %i" , a * b);
    return 0;
}
//
int del ( a , b )
{
    if (b == 0)
    {
        NSLog (@ "nehui delit na %i" , b );
        return 0;
    }
    
    NSLog (@ "delenie %i" , a / b );
    return 0;
}
