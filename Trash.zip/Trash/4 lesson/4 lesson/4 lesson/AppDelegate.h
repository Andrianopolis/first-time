//
//  AppDelegate.h
//  4 lesson
//
//  Created by user03 on 25.01.17.
//  Copyright © 2017 E. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

