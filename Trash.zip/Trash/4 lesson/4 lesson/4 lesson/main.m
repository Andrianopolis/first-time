#import <UIKit/UIKit.h>
#import "AppDelegate.h"

//обьявление класса
@interface SampleClass:NSObject

//обьявление прототипов методов
- (int)max:(int)num1 andNum2:(int)num2;
- (int)sum: (int)a andNum:(int)b;
@end

//описание класса
@implementation SampleClass

//описание функции 1
- (int)max:(int)num1 andNum2:(int)num2
{
    /* local variable declaration */
    int result;
    
    if (num1 > num2)
    {
        result = num1;
    }
    else
    {
        result = num2;
    }
    
    return result;
}

//описание функции 2
-(int)sum: (int)a andNum:(int)b
{
    return a + b;
}

@end

int main ()
{
    /* local variable definition */
    int a = arc4random()%10;
    int b = arc4random()%10;
    int ret;
    
    //делаем переменнкю типа данных SampleClass
    // и называем ее peremenaya
    SampleClass *peremenaya = [[SampleClass alloc]init];
    
    //вызываем метод который запішет в ret большее
    ret = [peremenaya max:a andNum2:b];
    NSLog(@"Max value is : %d\n", ret );
    
    
    for (int i = 0; i < ret; ++i)
    {
        NSLog(@"Now step %i", i);
        NSLog(@"Now value %i", [peremenaya sum:i andNum:b]);
    }
    
    
    return 0;
}
