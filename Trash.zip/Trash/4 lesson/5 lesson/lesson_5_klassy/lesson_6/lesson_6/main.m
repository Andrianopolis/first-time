//
//  main.m
//  lesson_6
//
//  Created by user03 on 01.02.17.
//  Copyright © 2017 E. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
