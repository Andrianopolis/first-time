//
//  ViewController.h
//  lesson_5_functioin
//
//  Created by user03 on 30.01.17.
//  Copyright © 2017 E. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

