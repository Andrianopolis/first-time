//
//  main.m
//  lesson_5_functioin
//
//  Created by user03 on 30.01.17.
//  Copyright © 2017 E. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"



//обьявление класса

@interface MyClass:NSObject



//обьявление прототипов методов

- (int)rez:(int)x andNum2:(int)n;



@end



//описание класса

@implementation MyClass



//описание функции 1

- (int)rez:(int)x andNum2:(int)n

{
    
    /* local variable declaration */
    
    int result;
    
    
    
    for (int i = 0; i < n; ++i)
        
    {
        result = x * x ;
        
        
        NSLog(@"Now step %i", i+1 );  //, @"x=" , x , @"*" , x , @"=" , result);
        
        NSLog(@"квадрат  %i", x  );
        NSLog(@" = " );
        NSLog(@"%i", result );
        
        x = result;
        
        NSLog(@"Now value %i", result);
        
    }
    
    
    
    
    
    
    return result;
    
}

@end







int main(int argc, char * argv[])



{
    
    /* local variable definition */
    
    int x = arc4random()%10;
    NSLog(@"X= %i", x);
    
    int n = arc4random()%4 ;
    NSLog(@"мы возведем значение Х в крадрат столько раз!= %i", n);
 NSLog(@"------------>>>>>" );
    NSLog(@" O O ");
NSLog(@" СИСЬКИ  ");
    NSLog(@"!!!  ");
    NSLog(@"   !!!");
    
    
    int ret;
    
    
    
    //делаем переменнкю типа данных SampleClass
    
    // и называем ее peremenaya
    
    MyClass *peremenaya = [[MyClass alloc]init];
    
    
    
    //вызываем метод который запішет в ret большее
    
    ret = [peremenaya rez:x andNum2:n];
    
    NSLog(@"X!= %d\n", ret );
    
    
    
    
    
    
    @autoreleasepool
    {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
